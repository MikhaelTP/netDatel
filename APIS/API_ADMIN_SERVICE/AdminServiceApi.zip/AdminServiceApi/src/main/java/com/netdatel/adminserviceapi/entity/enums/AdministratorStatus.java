package com.netdatel.adminserviceapi.entity.enums;

public enum AdministratorStatus {
    PENDING,
    ACTIVE,
    INACTIVE
}