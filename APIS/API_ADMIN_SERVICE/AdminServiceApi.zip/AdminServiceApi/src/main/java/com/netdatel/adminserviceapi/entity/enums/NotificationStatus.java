package com.netdatel.adminserviceapi.entity.enums;

public enum NotificationStatus {
    PENDING,
    SENT,
    FAILED,
    DELIVERED
}
