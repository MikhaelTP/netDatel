package com.netdatel.adminserviceapi.entity.enums;

public enum ModuleStatus {
    ACTIVE,
    INACTIVE,
    PENDING,
    EXPIRED
}
