package com.netdatel.adminserviceapi.entity.enums;

public enum TargetType {
    CLIENT,
    ADMINISTRATOR,
    WORKERS
}
