package com.netdatel.adminserviceapi.entity.enums;

public enum ClientStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
