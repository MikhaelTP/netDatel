package com.netdatel.adminserviceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
